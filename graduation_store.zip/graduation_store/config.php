<?php
$host = 'grad-store-db.cff2vs1xk6ft.us-east-1.rds.amazonaws.com';
$dbname = 'graduation_store';
$username = 'grad_admin'; 
$password = 'password'; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>