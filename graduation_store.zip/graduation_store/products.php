<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Graduation Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Graduation Store</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="products.php">Products</a>
            <a href="cart.php">Cart</a>
            <a href="add_product.php">Add Product (Admin)</a>
        </nav>
    </header>

    <main>
        <h2>Our Products</h2>
        
        <div class="products">
            <?php
            $stmt = $pdo->query("SELECT * FROM products");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo '<div class="product">';
                echo '<h3>' . htmlspecialchars($row['name']) . '</h3>';
                echo '<p>' . htmlspecialchars($row['description']) . '</p>';
                echo '<p>$' . number_format($row['price'], 2) . '</p>';
                echo '<form action="add_to_cart.php" method="post">';
                echo '<input type="hidden" name="product_id" value="' . $row['id'] . '">';
                echo '<input type="submit" value="Add to Cart" class="btn">';
                echo '</form>';
                echo '<a href="edit_product.php?id=' . $row['id'] . '" class="btn">Edit</a>';
                echo '<a href="delete_product.php?id=' . $row['id'] . '" class="btn" onclick="return confirm(\'Are you sure?\')">Delete</a>';
                echo '</div>';
            }
            ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2023 Graduation Store. All rights reserved.</p>
    </footer>
</body>
</html>