<?php
include 'config.php';

// Ensure session is started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Get or create session ID
$session_id = session_id();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart - Graduation Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Graduation Store</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="products.php">Products</a>
            <a href="cart.php">Cart</a>
            <a href="add_product.php">Add Product (Admin)</a>
        </nav>
    </header>

    <main>
        <h2>Your Shopping Cart</h2>
        
        <?php
        $stmt = $pdo->prepare("
            SELECT p.id, p.name, p.price, c.quantity 
            FROM cart c 
            JOIN products p ON c.product_id = p.id 
            WHERE c.session_id = ?
        ");
        $stmt->execute([$session_id]);
        
        $total = 0;
        $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($cart_items)) {
            echo '<p>Your cart is empty.</p>';
        } else {
            echo '<div class="cart-items">';
            foreach ($cart_items as $item) {
                echo '<div class="cart-item">';
                echo '<h3>' . htmlspecialchars($item['name']) . '</h3>';
                echo '<p>Price: $' . number_format($item['price'], 2) . '</p>';
                echo '<p>Quantity: ' . $item['quantity'] . '</p>';
                echo '<p>Subtotal: $' . number_format($item['price'] * $item['quantity'], 2) . '</p>';
                echo '<a href="remove_from_cart.php?product_id=' . $item['id'] . '" class="btn">Remove</a>';
                echo '</div>';
                
                $total += $item['price'] * $item['quantity'];
            }
            echo '</div>';
            
            echo '<div class="cart-total">';
            echo '<h3>Total: $' . number_format($total, 2) . '</h3>';
            echo '</div>';
        }
        ?>
        
        <a href="products.php" class="btn">Continue Shopping</a>
    </main>

    <footer>
        <p>&copy; 2023 Graduation Store. All rights reserved.</p>
    </footer>
</body>
</html>