<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    
    $stmt = $pdo->prepare("INSERT INTO products (name, description, price) VALUES (?, ?, ?)");
    $stmt->execute([$name, $description, $price]);
    
    header("Location: products.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Graduation Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Graduation Store</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="products.php">Products</a>
            <a href="cart.php">Cart</a>
            <a href="add_product.php">Add Product (Admin)</a>
        </nav>
    </header>

    <main>
        <h2>Add New Product</h2>
        
        <form method="post" class="product-form">
            <div>
                <label for="name">Product Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            
            <div>
                <label for="description">Description:</label>
                <textarea id="description" name="description" required></textarea>
            </div>
            
            <div>
                <label for="price">Price:</label>
                <input type="number" id="price" name="price" step="0.01" min="0" required>
            </div>
            
            <input type="submit" value="Add Product" class="btn">
        </form>
    </main>

    <footer>
        <p>&copy; 2023 Graduation Store. All rights reserved.</p>
    </footer>
</body>
</html>