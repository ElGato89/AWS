<?php
include 'config.php';

if (!isset($_GET['id'])) {
    header("Location: products.php");
    exit;
}

$id = $_GET['id'];

// Delete from cart first to maintain referential integrity
$stmt = $pdo->prepare("DELETE FROM cart WHERE product_id = ?");
$stmt->execute([$id]);

// Then delete the product
$stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
$stmt->execute([$id]);

header("Location: products.php");
exit;
?>