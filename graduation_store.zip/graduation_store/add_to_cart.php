<?php
include 'config.php';

// Ensure session is started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_POST['product_id'])) {
    header("Location: products.php");
    exit;
}

$product_id = $_POST['product_id'];
$session_id = session_id();

// Check if product already in cart
$stmt = $pdo->prepare("SELECT * FROM cart WHERE product_id = ? AND session_id = ?");
$stmt->execute([$product_id, $session_id]);
$existing_item = $stmt->fetch();

if ($existing_item) {
    // Update quantity
    $stmt = $pdo->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id = ?");
    $stmt->execute([$existing_item['id']]);
} else {
    // Add new item
    $stmt = $pdo->prepare("INSERT INTO cart (product_id, session_id, quantity) VALUES (?, ?, 1)");
    $stmt->execute([$product_id, $session_id]);
}

header("Location: cart.php");
exit;
?>