<?php
include 'config.php';

if (!isset($_GET['id'])) {
    header("Location: products.php");
    exit;
}

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    
    $stmt = $pdo->prepare("UPDATE products SET name = ?, description = ?, price = ? WHERE id = ?");
    $stmt->execute([$name, $description, $price, $id]);
    
    header("Location: products.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    header("Location: products.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Graduation Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Graduation Store</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="products.php">Products</a>
            <a href="cart.php">Cart</a>
            <a href="add_product.php">Add Product (Admin)</a>
        </nav>
    </header>

    <main>
        <h2>Edit Product</h2>
        
        <form method="post" class="product-form">
            <div>
                <label for="name">Product Name:</label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
            </div>
            
            <div>
                <label for="description">Description:</label>
                <textarea id="description" name="description" required><?= htmlspecialchars($product['description']) ?></textarea>
            </div>
            
            <div>
                <label for="price">Price:</label>
                <input type="number" id="price" name="price" step="0.01" min="0" value="<?= htmlspecialchars($product['price']) ?>" required>
            </div>
            
            <input type="submit" value="Update Product" class="btn">
        </form>
    </main>

    <footer>
        <p>&copy; 2023 Graduation Store. All rights reserved.</p>
    </footer>
</body>
</html>