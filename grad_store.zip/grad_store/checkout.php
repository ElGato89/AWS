<?php
session_start();
include 'db.php';

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "<p>Your cart is empty. <a href='index.php'>Shop now</a></p>";
    exit;
}

// Store cart items in the orderhistory table before clearing the cart
foreach ($_SESSION['cart'] as $product_id => $quantity) {
    $product_id = intval($product_id);
    $quantity = intval($quantity);

    $stmt = $conn->prepare("INSERT INTO orderhistory (product_id, quantity) VALUES (?, ?)");
    $stmt->bind_param("ii", $product_id, $quantity);
    $stmt->execute();
    $stmt->close();
}

// Clear cart after saving
$_SESSION['cart'] = [];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Checkout Complete</h1>
    <div class="container">
        <p>Thank you for your purchase! Your graduation items will be shipped shortly.</p>
        <a href="index.php" class="btn">Return to Store</a>
    </div>
</body>
</html>
