<?php
include 'db.php';
session_start();

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if (isset($_POST['add_to_cart'])) {
    $id = $_POST['product_id'];
    $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
    header("Location: cart.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Graduation Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Graduation Store</h1>
    <div class="container">
        <a href="cart.php" class="btn">View Cart</a>

        <?php
        $result = $conn->query("SELECT * FROM products");
        while ($row = $result->fetch_assoc()):
        ?>
            <div class="product">
                <img src="<?php echo $row['image']; ?>" alt="Product">
                <div class="product-info">
                    <h2><?php echo $row['name']; ?></h2>
                    <p><?php echo $row['description']; ?></p>
                    <p><strong>$<?php echo $row['price']; ?></strong></p>
                    <form method="post">
                        <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                        <button type="submit" name="add_to_cart">Add to Cart</button>
                    </form>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
