<?php
$host = "grad-store-db.cff2vs1xk6ft.us-east-1.rds.amazonaws.com";
$user = "grad_admin";
$password = "password";
$dbname = "graduation_store";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
