<?php
include 'db.php';
session_start();

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if (isset($_POST['update'])) {
    foreach ($_POST['quantities'] as $id => $qty) {
        if ($qty <= 0) {
            unset($_SESSION['cart'][$id]);
        } else {
            $_SESSION['cart'][$id] = $qty;
        }
    }
    header("Location: cart.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Your Cart</h1>
    <div class="container">
        <a href="index.php" class="btn">Continue Shopping</a>

        <?php if (empty($_SESSION['cart'])): ?>
            <p>Your cart is empty.</p>
        <?php else: ?>
            <form method="post">
                <?php
                $total = 0;
                foreach ($_SESSION['cart'] as $id => $qty):
                    $result = $conn->query("SELECT * FROM products WHERE id = $id");
                    $product = $result->fetch_assoc();
                    $subtotal = $qty * $product['price'];
                    $total += $subtotal;
                ?>
                    <div class="cart-item">
                        <img src="<?php echo $product['image']; ?>" alt="Product">
                        <div class="cart-info">
                            <h2><?php echo $product['name']; ?></h2>
                            <p>$<?php echo $product['price']; ?> x 
                                <input type="number" name="quantities[<?php echo $id; ?>]" value="<?php echo $qty; ?>" min="0">
                            = <strong>$<?php echo number_format($subtotal, 2); ?></strong></p>
                        </div>
                    </div>
                <?php endforeach; ?>
                <p><strong>Total: $<?php echo number_format($total, 2); ?></strong></p>
                <button type="submit" name="update">Update Cart</button>
                <a href="checkout.php" class="btn">Proceed to Checkout</a>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
