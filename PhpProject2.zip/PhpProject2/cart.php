<?php
include 'db.php';
session_start();

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if (isset($_POST['update'])) {
    foreach ($_POST['quantities'] as $id => $qty) {
        if ($qty <= 0) {
            unset($_SESSION['cart'][$id]);
        } else {
            $_SESSION['cart'][$id] = $qty;
        }
    }
    header("Location: cart.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
</head>
<body>
    <h1>Your Shopping Cart</h1>
    <a href="index.php">Continue Shopping</a>
    <hr>

    <form method="post">
        <table border="1">
            <tr><th>Item</th><th>Quantity</th><th>Price</th><th>Subtotal</th></tr>
            <?php
            $total = 0;
            foreach ($_SESSION['cart'] as $id => $qty) {
                $result = $conn->query("SELECT * FROM products WHERE id = $id");
                $product = $result->fetch_assoc();
                $subtotal = $qty * $product['price'];
                $total += $subtotal;
            ?>
                <tr>
                    <td><?php echo $product['name']; ?></td>
                    <td>
                        <input type="number" name="quantities[<?php echo $id; ?>]" value="<?php echo $qty; ?>">
                    </td>
                    <td>$<?php echo $product['price']; ?></td>
                    <td>$<?php echo number_format($subtotal, 2); ?></td>
                </tr>
            <?php } ?>
            <tr><td colspan="3"><strong>Total:</strong></td><td>$<?php echo number_format($total, 2); ?></td></tr>
        </table>
        <br>
        <button type="submit" name="update">Update Cart</button>
    </form>
    <br>
    <a href="checkout.php">Proceed to Checkout</a>
</body>
</html>

