CREATE DATABASE IF NOT EXISTS graduation_store;
USE graduation_store;

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL
);

INSERT INTO products (name, description, price) VALUES
('Graduation Cap', 'Classic black cap for graduation day.', 15.00),
('Graduation Gown', 'Elegant black gown in various sizes.', 45.00),
('Tassel', 'Comes in various colors to match your school.', 5.00),
('Yearbook', 'Hardcover school yearbook.', 25.00),
('Souvenir Mug', 'Graduation-themed mug.', 10.00);
