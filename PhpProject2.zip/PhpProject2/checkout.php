<?php
include 'db.php';
session_start();

if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    echo "Your cart is empty. <a href='index.php'>Shop now</a>";
    exit;
}

// Simulate checkout
$_SESSION['cart'] = [];

?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout Complete</title>
</head>
<body>
    <h1>Thank you for your purchase!</h1>
    <p>Your graduation items will be delivered soon.</p>
    <a href="index.php">Back to Store</a>
</body>
</html>

